// Add to History Function Needs
// 1. Empty Array to Store History And DOM Address
const historyCard = document.querySelector(".card-history");

// 2. Function Length Checker
function checkHistoryLength(artBoxUrl, gameHistory) {
  if (gameHistory.length >= 3) {
    gameHistory.shift(artBoxUrl);
  }
  gameHistory.push(artBoxUrl);

  saveHistoryToLocalStorage();
}

// 3. Function to Save History
function saveHistoryToLocalStorage() {
  localStorage.setItem("gameHistory", JSON.stringify(gameHistory));
}

// 4. Function to Load History
function loadHistoryFromLocalStorage() {
  const historyJSON = localStorage.getItem("gameHistory");
  if (historyJSON) {
    gameHistory = JSON.parse(historyJSON);
    console.log("game history:", gameHistory);
    return gameHistory;
  }
  return null;
}

// // 5. Function to Display History
// function displayHistory() {
//   // historyCard.style.backgroundImage = `url(${})`;
//   for (let i = 0; i < gameHistory.length; i++) {
//     const element = gameHistory[i];
//     historyCard.style.backgroundImage = element;
//     historyCard.style.backgroundSize = "cover";
//   }
// }

// Main Function addToHistory
function addToHistory(artBoxUrl) {
  let gameHistory = loadHistoryFromLocalStorage();
  if (gameHistory === null) {
    gameHistory = [];
  }
  checkHistoryLength(artBoxUrl, gameHistory);
  // displayHistory();
}

export { addToHistory };
